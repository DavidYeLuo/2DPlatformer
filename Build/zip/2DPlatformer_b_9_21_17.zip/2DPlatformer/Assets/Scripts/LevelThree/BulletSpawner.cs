﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    public Transform north;
    public Transform east;
    public Transform west;

    public RedBullet redBullet;
    public BlueBullet blueBullet;

    public int bulletCount;
    private int count;

    private IEnumerator Spawn()
    {
        yield return new WaitForSeconds(1);

        while(true)
        {
            while(count < bulletCount)
            {
                    // Spawn redBullet
                    if (Random.Range(0, 2) == 0)
                    {
                        //Instantiate(redBullet,)
                    }
                    else
                    {
                        // Instantiate()
                    }
                
            }
        }
    }
    private void SpawnAtNorth(Bullet bullet)
    {
        Instantiate(bullet, new Vector3(Random.Range(-18.0f, 18.0f), north.transform.position.y, -1), Quaternion.identity);
    }
    private void SpawnAtEast(Bullet bullet)
    {
        Instantiate(bullet, new Vector3(east.transform.position.x, Random.Range(-9.5f, 22.5f), -1), Quaternion.identity);
    }
    private void SpawnAtWest(Bullet bullet)
    {
        Instantiate(bullet, new Vector3(west.transform.position.x, Random.Range(-9.5f, 22.5f), -1), Quaternion.identity);
    }

}
