﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    public Transform north;
    public Transform east;
    public Transform west;

    public RedBullet redBullet;
    public BlueBullet blueBullet;

    public int bulletCount;
    private int count;
	private List<Bullet> bullets = new List<Bullet>();

	public GameObject playerRef;
	private SimplePlatformController2 player;

	private void Start()
	{
		player = playerRef.GetComponent<SimplePlatformController2>();
		StartCoroutine(Spawn());
	}
	void Update(){
		//Debug.Log (bullets.Count);
	}
    private IEnumerator Spawn()
    {
            while(count < bulletCount)
            {
			// Debug.Log ("Function Called");
                    // Spawn redBullet
				
                    if (Random.Range(0, 2) == 0)
                    {
						SpawnAtNorth (redBullet);
						SpawnAtEast (redBullet);
						SpawnAtWest (redBullet);
                    }
                    else
                    {
						SpawnAtNorth(blueBullet);
						SpawnAtEast(blueBullet);
						SpawnAtWest(blueBullet);
                    }
			count++;
			yield return new WaitForSeconds(1);
		}
    }
    private void SpawnAtNorth(Bullet bullet)
    {
		Bullet obj = Instantiate (bullet, new Vector3 (Random.Range (-18.0f, 18.0f), north.position.y, -1), Quaternion.Euler (0, 0, -90));
			bullets.Add(obj);
			obj.GetComponent<Rigidbody2D>().velocity = new Vector3(0,-5,0);
    }
    private void SpawnAtEast(Bullet bullet)
    {
		//Debug.Log (bullets.Count);
		Bullet obj = Instantiate(bullet, new Vector3(east.transform.position.x, Random.Range(-9.5f, 22.5f), -1), Quaternion.Euler(0,0,180));
		bullets.Add (obj);
			obj.GetComponent<Rigidbody2D>().velocity = new Vector3(-10,0,0);
    }
    private void SpawnAtWest(Bullet bullet)
    {
		Bullet obj = Instantiate (bullet, new Vector3 (west.transform.position.x, Random.Range (-9.5f, 22.5f), -1), Quaternion.identity);
			obj.GetComponent<Rigidbody2D>().velocity = new Vector3(10,0,0);
    }

	public void Red()
	{
		Debug.Log (bullets.Count);
		for (int i = 0; i < bullets.Count; i++) 
		{
			if (bullets [i] == null) 
			{
				bullets.RemoveAt (i);
			}
			else if (bullets [i].name.Equals ("Red")) 
			{
				bullets [i].GetComponent<BoxCollider2D> ().isTrigger = true;
			} 
			else if (bullets [i].name.Equals ("Blue")) 
			{
				bullets [i].GetComponent<BoxCollider2D> ().isTrigger = false;
			}
		}
	}
	public void Blue()
	{
		int num = 0;
		for (int i = 0; i < bullets.Count; i++) 
		{
			if (bullets [i] == null) 
			{
				bullets.RemoveAt (i);
			}
			else if (bullets [i].name.Equals ("Red")) 
			{
				bullets [i].GetComponent<BoxCollider2D> ().isTrigger = false;
			} 
			else if (bullets [i].name.Equals ("Blue")) 
			{
				bullets [i].GetComponent<BoxCollider2D> ().isTrigger = true;
			}
			num++;
		}
		// Debug.Log (bullets.Count);
	}

}
