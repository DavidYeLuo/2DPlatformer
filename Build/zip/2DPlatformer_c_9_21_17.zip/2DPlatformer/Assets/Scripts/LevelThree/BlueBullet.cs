﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueBullet : Bullet {

	// Use this for initialization
	void Start () {
		base.name = "Blue";
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
